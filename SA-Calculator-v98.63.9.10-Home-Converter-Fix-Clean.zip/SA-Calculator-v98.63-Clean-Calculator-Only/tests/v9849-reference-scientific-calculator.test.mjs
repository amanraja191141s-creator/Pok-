import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');

test('v98.49 Scientific Calculator follows the supplied reference composition', () => {
  const html = read('index.html');
  const screen = html.slice(html.indexOf('id="screen-scientific"'), html.indexOf('</section>', html.indexOf('id="screen-scientific"')));
  for (const id of ['sci-angle-indicator','sci-memory-indicator','sci-history-toggle','sci-more-toggle','sci-shift-toggle','sci-angle-toggle','sci-expression','sci-result','sci-history-panel','sci-more-functions']) assert.ok(screen.includes(id), `missing ${id}`);
  assert.equal((screen.match(/data-sci-insert=/g)||[]).length, 41, '18 primary and 5 additional functions plus 18 keypad insert controls are present');
  const primary = screen.slice(screen.indexOf('class="scientific-function-grid"'), screen.indexOf('class="scientific-more-functions"'));
  const extra = screen.slice(screen.indexOf('class="scientific-more-functions"'), screen.indexOf('class="scientific-memory-row"'));
  assert.equal((primary.match(/data-sci-insert=/g)||[]).length, 18);
  assert.equal((extra.match(/data-sci-insert=/g)||[]).length, 5);
  assert.match(extra, /data-sci-action="ans"/);
  assert.equal((screen.match(/class="sci-operator"/g)||[]).length, 4);
  assert.equal((screen.match(/data-sci-memory=/g)||[]).length, 5);
  assert.equal((screen.match(/data-sci-action="(?:clear|delete|equals|cursor-left|cursor-right|sign|toggle-angle)"/g)||[]).length, 7);
});

test('v98.49 scientific keypad uses six function columns and five numeric columns with four rows', () => {
  const css = read('assets/css/app.css');
  assert.match(css, /scientific-function-grid\s*\{[\s\S]*?grid-template-columns:repeat\(6,minmax\(0,1fr\)\)/);
  assert.match(css, /scientific-keypad\s*\{[\s\S]*?grid-template-columns:repeat\(5,minmax\(0,1fr\)\)/);
  assert.match(css, /scientific-keypad\s*\{[\s\S]*?grid-template-rows:repeat\(4,minmax\(52px,1fr\)\)/);
  assert.match(css, /scientific-keypad button\s*\{[\s\S]*?min-height:52px/);
  assert.match(css, /@media\(max-height:740px\)/);
  assert.match(css, /@media\(max-width:360px\)/);
});

test('scientific controls are wired: shift mapping, angle toggle, caret movement, sign, memory, history and More', () => {
  const js = read('assets/js/app.js');
  assert.match(js, /data-sci-alt-insert/);
  assert.match(js, /name === 'cursor-left'/);
  assert.match(js, /name === 'cursor-right'/);
  assert.match(js, /name === 'sign'/);
  assert.match(js, /name === 'toggle-angle'/);
  assert.match(js, /#sci-more-toggle/);
  assert.match(js, /sa_scientific_memory_v1/);
  assert.match(js, /sa_scientific_history_v1/);
  assert.match(js, /editor\.setSelectionRange/);
});

test('v98.49 release, stylesheet build, offline cache and workflow are synchronized', () => {
  const pkg = JSON.parse(read('package.json'));
  const manifest = JSON.parse(read('manifest.webmanifest'));
  const html = read('index.html');
  const js = read('assets/js/app.js');
  const sw = read('service-worker.js');
  const builder = read('scripts/prepare-android-web.mjs');
  const wf = read('.github/workflows/main.yml');
  assert.equal(pkg.version, '1.98.64-v98.63.9');
  assert.equal(manifest.version, pkg.version);
  assert.ok(html.includes(pkg.version));
  assert.ok(js.includes(`const APP_VERSION = '${pkg.version}'`));
  assert.match(html,/assets\/css\/app\.css/);
  assert.match(builder,/assets\/css\/app\.css/);
  assert.match(sw, /sa-calculator-v98-63-9-clean-runtime-v98639/);
  assert.match(wf, /SA_EXPECTED_VERSION: '1\.98\.64-v98\.63\.9'/);
  assert.match(wf, /1098064/);
  assert.equal(wf, read('.github/workflows/main.yml'));
});
