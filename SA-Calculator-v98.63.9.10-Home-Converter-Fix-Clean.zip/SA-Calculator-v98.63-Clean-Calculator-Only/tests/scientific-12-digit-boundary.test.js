'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '..', 'assets/js/app.js'), 'utf8');
function extract(name) {
  const start = source.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `${name} not found`);
  const open = source.indexOf('{', start); let depth = 0;
  for (let i = open; i < source.length; i++) {
    if (source[i] === '{') depth++;
    else if (source[i] === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`Could not extract ${name}`);
}
function runtime() {
  const context = {
    STATE: { precision: 'auto', trailingZeros: false, thousandsSep: 'comma' },
    Math, Number, String
  };
  vm.runInNewContext([
    extract('toSuperscriptExponent'),
    extract('formatScientificEntryDisplay'),
    extract('formatResultNumber'),
    extract('calculatorIntegerDigitCount'),
    extract('calculatorNeedsScientificNotation'),
    extract('formatCalculatorResultNumber'),
    extract('isScientificEntryExpression'),
    extract('formatCalculatorExpressionResult'),
    'globalThis.digits=calculatorIntegerDigitCount;',
    'globalThis.needs=calculatorNeedsScientificNotation;',
    'globalThis.format=formatCalculatorResultNumber;',
    'globalThis.preview=formatCalculatorExpressionResult;'
  ].join('\n'), context);
  return context;
}
test('12 integer digits stay ordinary and digit 13 switches to scientific notation', () => {
  const r = runtime();
  assert.equal(r.digits(999999999999), 12);
  assert.equal(r.digits(1000000000000), 13);
  assert.equal(r.format(999999999999), '999,999,999,999');
  assert.equal(r.format(-999999999999), '-999,999,999,999');
  assert.equal(r.format(1000000000000), '1×10¹²');
  assert.equal(r.format(-1000000000000), '-1×10¹²');
});
test('display rounding cannot leak a 13-digit ordinary integer across the boundary', () => {
  const r = runtime();
  assert.equal(r.format(999999999999.4), '999,999,999,999');
  assert.equal(r.format(999999999999.6), '1×10¹²');
});
test('scientific mantissa always has at most six fractional digits and strips trailing zeroes', () => {
  const r = runtime();
  assert.equal(r.format(1234567890123), '1.234568×10¹²');
  assert.equal(r.format(1500000000000), '1.5×10¹²');
  assert.equal(r.format(100000000000000000000), '1×10²⁰');
  assert.equal(r.format(0.0000001), '1×10⁻⁷');
});
test('integer digit counting is independent of sign and grouping preferences', () => {
  const r = runtime();
  assert.equal(r.digits(-123456789012), 12);
  assert.equal(r.digits(123456789012), 12);
  assert.equal(r.digits(1234567890123), 13);
  assert.equal(r.needs(999999999999), false);
  assert.equal(r.needs(1000000000000), true);
});

test('live preview and radical-result paths use the same rounded 12/13-digit boundary', () => {
  const r = runtime();
  assert.equal(r.preview('999999999999', 999999999999), '999,999,999,999');
  assert.equal(r.preview('999999999999.6', 999999999999.6), '1×10¹²');
  assert.equal(r.preview('e20', 1e20), '1×10²⁰');
  assert.equal(r.preview('√(999999999999.6^2)', 999999999999.6), '1×10¹²');
});
test('user precision settings cannot render a rounded 13-digit integer in ordinary notation', () => {
  const r = runtime();
  r.STATE.precision = '2';
  assert.equal(r.format(999999999999.4), '999,999,999,999.4');
  assert.equal(r.format(999999999999.996), '1×10¹²');
  r.STATE.precision = '0';
  assert.equal(r.format(999999999999.4), '999,999,999,999');
  assert.equal(r.format(999999999999.6), '1×10¹²');
});

test('scientific exponent-entry uses the same threshold: e11 ordinary, e12 scientific', () => {
  const r = runtime();
  assert.equal(r.preview('e11', 1e11), '100,000,000,000');
  assert.equal(r.preview('e12', 1e12), '1×10¹²');
  assert.equal(r.preview('2e11', 2e11), '200,000,000,000');
  assert.equal(r.preview('2e12', 2e12), '2×10¹²');
});
