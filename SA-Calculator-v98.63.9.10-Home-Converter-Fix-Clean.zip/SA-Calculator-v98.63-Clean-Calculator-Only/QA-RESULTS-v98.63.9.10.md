# QA Results — v98.63.9.10

- `node --check assets/js/app.js`: PASS
- `npm run build:web`: PASS
- `npm test`: PASS — 378 tests, 0 failures
- Currency picker: selected-only on initial open; alternatives revealed only by non-empty search query (source-level regression coverage).
- Unit picker: same selected-only behavior (source-level regression coverage).
- Home display max width: 700px; responsive min-height.
- Keypad buttons: reduced to 64–66% dimensions with 36px minimum height.
- ZIP integrity: verified after packaging.

Not performed: APK build/install on a physical Android device, runtime screenshots, touch-latency/performance benchmark. Automated tests do not establish device-level zero bugs or lag-free performance.
